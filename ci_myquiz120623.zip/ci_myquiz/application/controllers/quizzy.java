import java.util.Scanner;
public class quizzy {
    public static void main(String[] args) {
        int x = sc.nextInt();
        int y = sc.nextInt();
        int sum = (int) (y + x) / 2;
    
        int x = 1;
        System.out.print(--x);
        System.out.print(x);
        if (age >= 18) {
            System.out.println("Of age");
        }System.out.println("Good luck");

        int x;
        do
        

    }
    
    

}


    

