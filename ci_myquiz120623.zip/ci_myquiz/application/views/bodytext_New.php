<style>
    @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+Thai&display=swap');
    body {
        font-family: 'Noto Sans Thai', sans-serif;
    }
</style>

<div style="background-color:DFE9EC;">
    <div class="container" style="background-color:DFE9EC;">
        <div class="row">
            <div class="col-md-12"></div>
            <div class="mx-auto">
                <br>
                <center>
                    <h2>คลังข้อสอบสำหรับการเขียนโปรแกรมภาษาจาวา</h2>
                    <br>
                    <img src="<?php echo base_url('img/Java_icon.png'); ?>" width=“140px” height=140px>
                    <br><br><br>
                    <h4>เนื้อหาทั้งหมด</h4>
                    <br>

                    <!-- onclick="location.href='<?php echo base_url();?>Home_new/unit1'  -->
                    
                    <button type="buttonUnit1" class="btn btn-light btn-lg" style="text-align: left; width:850; height:70;" onclick="location.href='<?php echo base_url();?>index.php/Unit1'" >บทที่ 1 การเขียนโปรแกรมเบื้องต้นด้วยภาษาจาวา </button>
                    <br><br>

                    <button type="buttonUnit2" class="btn btn-light btn-lg" style="text-align: left; width:850; height:70;" onclick="location.href='<?php echo base_url();?>index.php/Unit2'" >บทที่ 2 การเขียนโปรแกรมแบบมีทางเลือก </button>
                    <br><br>

                    <button type="buttonUnit3" class="btn btn-light btn-lg" style="text-align: left; width:850; height:70;" onclick="location.href='<?php echo base_url();?>index.php/unit3'" >บทที่ 3 การเขียนโปรแกรมแบบทำซ้ำ </button>
                    <br><br>

                    <button type="buttonUnit4" class="btn btn-light btn-lg" style="text-align: left; width:850; height:70;" onclick="location.href='<?php echo base_url();?>index.php/unit4'" >บทที่ 4 วิธีการสร้างและใช้งานเมธอด </button>
                    <br><br>

                    <button type="buttonUnit5" class="btn btn-light btn-lg" style="text-align: left; width:850; height:70;" onclick="location.href='<?php echo base_url();?>index.php/unit5'" >บทที่ 5 อาร์เรย์</button>
                    <br><br>
                    
                    <br><br>
                    
                </center>




            </div>

        </div>
    </div>
</div>